//
//  WatchNotesApp.swift
//  WatchNotes
//
//  Created by WD on 2023/8/11.
//

import SwiftUI

@main
struct WatchNotesApp: App {
    var body: some Scene {
        WindowGroup {
            NotesListView()
        }
    }
}
