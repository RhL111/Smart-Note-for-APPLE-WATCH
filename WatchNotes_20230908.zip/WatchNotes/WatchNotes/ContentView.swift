//
//  ContentView.swift
//  WatchNotes
//
//  Created by WD on 2023/8/11.
//

import SwiftUI

struct NotesListView: View {
    
    // MARK: - PROPERTIES
    @AppStorage("lineCount") var lineCount : Int = 1
    
    @ObservedObject private var noteManager: NoteManager = NoteManager.shared
    
    @State private var isSettingsPresented : Bool = false
    
    let dateFormatter: DateFormatter
    
    // MARK: - FUNCTION
    func presentAddNoteInput() {
        
    }
    
    init() {
        dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
    }
    
    // MARK: - BODY
    var body: some View {
        
        VStack {
            
            if noteManager.notes.count >= 1 {
                List {
                    ForEach (0..<noteManager.notes.count,id: \.self){ i in
                        HStack {
                            Capsule()
                                .frame(width: 5)
                                .foregroundColor(noteManager.notes[i].finished ? Color("ThemeColorFinished") : Color("ThemeColor"))
                            VStack(alignment: .leading, content: {
                                Text(noteManager.notes[i].text)
                                    .lineLimit(lineCount)
                                    .foregroundStyle(Color.black)
                                    .padding(.leading,5)
                                Text(noteManager.notes[i].date, formatter: dateFormatter)
                                    .lineLimit(1)
                                    .font(.footnote)
                                    .padding(.leading,5)
                            })
                            
                            Spacer()
                            
                            Image(systemName: noteManager.notes[i].finished ? "checkmark.square" : "square")
                                .imageScale(.large)
                                .onTapGesture {
                                    NoteManager.shared.toggleFinish(at: i)
                                }
                        }
                    }
                    .onDelete { indexSet in
                        NoteManager.shared.delete(offset: indexSet)
                    }
                }
            } else {
                Spacer()
                Image(systemName: "note.text")
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.gray)
                    .opacity(0.3)
                    .padding(25)
                Spacer()
            }
        }
        .navigationTitle("Notes")
        .onAppear {
            
            NoteManager.shared.load()
                        
            print(noteManager.notes)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        NotesListView()
    }
}
