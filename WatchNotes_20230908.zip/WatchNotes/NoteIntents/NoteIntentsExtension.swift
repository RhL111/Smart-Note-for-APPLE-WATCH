//
//  NoteIntentsExtension.swift
//  NoteIntents
//
//  Created by WD on 2023/9/5.
//

import AppIntents

@main
struct NoteIntentsExtension: AppIntentsExtension {
}
