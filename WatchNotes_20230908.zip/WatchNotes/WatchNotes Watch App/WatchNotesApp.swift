//
//  WatchNotesApp.swift
//  WatchNotes Watch App
//
//  Created by WD on 2023/8/11.
//

import SwiftUI

@main
struct WatchNotes_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                NotesListView()
            }
        }
    }
}
