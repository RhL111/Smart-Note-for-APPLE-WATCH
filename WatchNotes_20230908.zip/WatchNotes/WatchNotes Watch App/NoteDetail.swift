//
//  NoteDetail.swift
//  WatchNotes Watch App
//
//  Created by WD on 2023/8/11.
//

import SwiftUI

struct NoteDetail: View {
    // MARK: - PROPERTIES
    let note : Note
    let count : Int
    let index : Int
    
    @State private var isCreditsPresented : Bool = false
    
    let dateFormatter: DateFormatter

    // MARK: - FUNCTION
    
    // MARK: - BODY
    var body: some View {
        VStack(alignment: .center, spacing: 3) {
            
            //HEADER
            HeaderView(title: "")
            
            //Context
            Spacer()
            ScrollView(.vertical, showsIndicators: false) {
                Text(note.text)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.leading)
                Text(note.date, formatter: dateFormatter)
                    .font(.footnote)
            }
            
        }//:VStack
        .padding(5)
    }
}

struct NoteDetail_Previews: PreviewProvider {
    static var previews: some View {
        
        let sampleNote: Note = Note(id: UUID(), text: "Sample Note")

        NoteDetail(note: sampleNote, count: 5, index: 1, dateFormatter: DateFormatter())
    }
}
