//
//  Note.swift
//  WatchNotes Watch App
//
//  Created by WD on 2023/8/11.
//

import Foundation


struct Note: Codable , Identifiable {
    let id: UUID
    let text: String
    var date: Date = Date()
    var finished: Bool = false
}
