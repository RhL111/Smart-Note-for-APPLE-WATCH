//
//  NoteManager.swift
//  WatchNotes Watch App
//
//  Created by WD on 2023/9/4.
//

import SwiftUI

class NoteManager: ObservableObject {
    
    static let shared = NoteManager()

    @Published var notes: [Note] = []
    
    
    func toggleFinish(at index: Int) {
        
        notes[index].finished.toggle()

        save()
    }
    
    func add(_ aNote: Note) {
        
        withAnimation {
            
            notes.insert(aNote, at: 0)
            
            save()
        }
    }
    
    func delete(offset:IndexSet) {
        withAnimation {
            notes.remove(atOffsets: offset)
            save()
        }
    }
    
    func delete(_ note: Note) {
        
        notes.removeAll(where: {$0.id == note.id })
        save()
    }
    
    func load() {
        DispatchQueue.main.async {
            do {
                
                let url = self.getDocumentDirectory().appendingPathComponent("notes")
                
                let data = try Data(contentsOf: url)
                
                self.notes = try JSONDecoder().decode([Note].self, from: data)
                
                print("load notes: \(self.notes)")
                
            } catch {
                
            }
        }
    }
    
    func save() {
        do {
            let data  = try JSONEncoder().encode(notes)
            let url = getDocumentDirectory().appendingPathComponent("notes")
            try data.write(to: url)
        } catch {
            print("Saving data has failed!!")
        }
    }
    
    func noteContent(for id: UUID) -> String {
        
        if let note = notes.filter({ $0.id == id }).first {
            return note.text
        }
        
        return ""
    }
    
    func getDocumentDirectory() -> URL {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return path[0]
    }
}
