//
//  AddNoteIntent.swift
//  WatchNotes Watch App
//
//  Created by WD on 2023/9/4.
//

import AppIntents

struct NoteEntity: AppEntity {
    
    static var typeDisplayRepresentation: TypeDisplayRepresentation = TypeDisplayRepresentation(name: "Note Content")
    
    static var defaultQuery: NoteContentQuery = NoteContentQuery()
    
    var id: UUID
    
    @Property(title: "Text")
    var text: String
    
    @Property(title: "Date")
    var date: Date
    
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "Note Content")
    }
    
    init(id: UUID, text: String, date: Date) {
        self.id = id
        self.text = text
        self.date = date
    }
}

struct NoteContentQuery: EntityQuery {
    
    func entities(for identifiers: [UUID]) async throws -> [NoteEntity] {
        
        return identifiers.compactMap { identifier in
            
            let note = NoteManager.shared.notes.filter({$0.id == identifier}).first!

           return NoteEntity(id: identifier, text: note.text, date: note.date)
        }
    }
}

struct SiriAddNote: AppIntent {
    
    static var title: LocalizedStringResource = "Add Note"
    
    static var description = IntentDescription("Adds a note")
    
    static var openAppWhenRun: Bool = true
    
    @Parameter(title: "Note Content")
    var content: String?
    
    static var parameterSummary: some ParameterSummary {
        Summary("Add Note")
    }
    
    @MainActor
    func perform() async throws -> some IntentResult {
        
        guard let content = content else {
            throw $content.requestValue("What do you want to note?")
        }
        
        guard !content.isEmpty else {
            throw $content.requestValue("Content can't be empty")
        }
        
        let note = Note(id: UUID(), text: content)
        
        NoteManager.shared.add(note)
        
        return .result(dialog: "Okay, added note successfully.")
    }
}

struct SiriDeleteNote: AppIntent {
    
    static var title: LocalizedStringResource = "Delete Note"
    
    static var description = IntentDescription("Delete a note")
    
    static var openAppWhenRun: Bool = true
    
    @Parameter(title: "Note Delete")
    var noteContent: String?
    
    static var parameterSummary: some ParameterSummary {
        Summary("Delete Note")
    }
    
    @MainActor
    func perform() async throws -> some IntentResult {
        
        let noteContent = try await $noteContent.requestDisambiguation(among: NoteManager.shared.notes.map({ $0.text }), dialog: IntentDialog("Which note would you like to delete?"))

        let note = NoteManager.shared.notes.filter({$0.text.elementsEqual(noteContent)}).first!

        NoteManager.shared.delete(note)
        
        return .result(dialog: "Okay, delete note successfully.")
    }
}

struct SiriAddNoteShortcuts: AppShortcutsProvider {
    
    static var appShortcuts: [AppShortcut] {
        
        AppShortcut(intent: SiriAddNote(), phrases: ["Add a note to \(.applicationName)"])
        
        AppShortcut(intent: SiriDeleteNote(), phrases: ["Delete a note from \(.applicationName)"])
    }
    
    static var shortcutTileColor: ShortcutTileColor {
        .red
    }
}
